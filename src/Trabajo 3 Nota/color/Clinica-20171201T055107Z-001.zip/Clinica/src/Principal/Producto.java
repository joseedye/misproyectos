/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Principal;

/**
 *
 * @author Astrid Caicedo
 */
public class Producto {
    private String idProducto;
    private String nombreProducto;
    private int precio;
    private String descripcion;
}
